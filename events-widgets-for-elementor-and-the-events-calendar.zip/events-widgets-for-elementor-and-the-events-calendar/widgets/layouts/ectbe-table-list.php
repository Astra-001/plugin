<?php
        // tags get values
        $tagList = [];
        $terms2 = get_the_tags($event['id']);

        if (is_array($terms2)){
            foreach ($terms2 as $term)
            {
                array_push($tagList, $term->slug);
            }
        }
        $tagValues = !count($tagList) > 0 ? 'N/A' : implode(',', $tagList);

        $events_html .= '<tr >
        <td>' . $key . '</td>';
        if ($eventimgurl == "")
        {
            $events_html .= '<td><img src="' . ECTBE_URL . 'assets/images/event-template-bg.png' . '" width="60" height="60"></td>';
        }
        else
        {
            $events_html .= '<td><img src="' . $eventimgurl. '"></td>';
        }

        $events_html .= '<td class="ectbe-table-tittle-name">' . __($event_title , 'ectbe') . '</td>';
        
        if ($display_desc == 'yes')
        {
            $events_html .= ' <td>' . __($evt_desc , 'ectbe') . '</td>';
        }

        $events_html .= '<td>' . __($event_schedule , 'ectbe') . '</td>';

        // Category Column
        if($display_cate=='yes')
        {
           
            $categoryList = !$ectbe_cate == false ? $ectbe_cate : 'N/A';
            $events_html .= '<td>' . __($categoryList , 'ectbe') . '</td>';
        }

        // Tag Column 
        $events_html .= '<td>' . __(esc_html($tagValues) , 'ectbe') . '</td>';

        // Venue Column 
        if ($ectbe_venue == 'no') 
        {
            $ev_Venue = isset($venue_details['linked_name']) ? $venue_details_html : 'N/A';
            $events_html .= '<td >' .__($ev_Venue , 'ectbe').'</td>';
        }

        $events_html .= '<td>' . __($ev_cost == null ? 'N/A' : $ev_cost , 'ectbe') . '</td>
        <td ><span  class="ectbe_viewMore "><a href="' . esc_attr($url) . '" >' . __(esc_html("View More") , 'ectbe') . '</a></span></td></tr>';
      


