<?php
if ($style == 'style-2')
{

}
else
{
    $html_code .= '<div id="etcbe_selct_div" class="ectbe-category-filter ectbe-table ">';
    
    // Category Select Box 
    $html_code .= ' <select id="ectbe-categoryFilter">
			            <option value="" hidden> Category </option>';
    foreach ($cat_List as $term)
    {
        $events_html .= '<option value="' . $term->slug . '">' . $term->name . '</option>';
    }

    $html_code .= '</select>';

    // Tag list Select Box 
    $html_code .= ' <select id="ectbe-tagFilter">
			        <option value="" hidden> Tags </option>';
    foreach ($tag_list as $term)
    {
        $html_code .= '<option value="' . $term->slug . '">' . $term->name . '</option>';
    }
    $html_code .= '</select><span class=" ectbe-table-refresh dashicons dashicons-image-rotate"></span> </div>';
    $html_code .= ' <table id="ectbe-table-List" class="ectbe-table" >';
    $html_code .= '<thead  class ="ectbe-table-head"  ><tr>
    <th colspan="1">' . __('S.No', 'ectbe') . '</th>
    <th colspan="1" >' . __('Image', 'ectbe') . '</th>
    <th>' . __('Event Name', 'ectbe') . '</th>';

    // Check  Description Allowed or Not

    if ($display_desc == 'yes')
    {
        $html_code .= '<th>' . __('Description', 'ectbe') . '</th>';
    }

    $html_code .= '<th>' . __('Date', 'ectbe') . ' </th>';

       // Category Allowed or not
       if ($display_cate == 'yes')
       {
           $html_code .= '<th>' . __('Category', 'ectbe') . '</th>';
       }

        $html_code .= '<th>' . __('Tags', 'ectbe') . '</th>';

        // Venue Location Allowed or not
        if ($ectbe_venue == 'no')
        {
            $html_code .= '<th>' . __('Venue', 'ectbe') . ' </th>';
        }

        $html_code .= '<th>' . __(' Organiser Name', 'ectbe') . ' </th>
        <th>' . __(' Cost ', 'ectbe') . '</th>
        <th>' . __('Post link', 'ectbe') . '</th>
    </tr>

    </thead>
    <tbody >';
    // var_dump($all_events);
    foreach ($all_events as $key => $event)
    {
        // tags get values
        $tagList = [];
        $terms2 = get_the_tags($event_id);
        // var_dump($terms2);
        if (is_array($terms2)) foreach ($terms2 as $term)
        {
            array_push($tagList, $term->slug);
        }
        $key += 1;
        //Tag List Check
        $tagValues = !count($tagList) > 0 ? 'NA' : implode(' ', $tagList);

        // Event dates check
        $ev_date = isset( $event['event_schedule'] )? $event['event_schedule'] : 'Not Defined' ;

        // venue Details check
        $venue = tribe_get_venue($event['id']);
        $venue = (!isset($venue)) ? 'NA' : $venue;
        // Venue Link
        $venue_link = tribe_get_venue_website_url($event['id']);
        $venue_link = (!isset($venue_link)) ? 'NA' : $venue_link;

        // Category Variable check
        $category = tribe_get_event_cat_slugs($event['id']);
        if (is_array($category))
        {
            $categoryStr = implode(", ", $category);
            $category = (strlen($categoryStr) > 0) ? $categoryStr : 'NA';
        }

        // Oragniser Variable check
        $organizer_name = tribe_get_organizer($event['id']);
        $organizer = !$organizer_name == NUll ? $organizer_name : "NA";

        // Table Row
        $html_code .= '<tr >
        <td>' . $key . '</td>';
        if ($event['eventimgurl'] == "")
        {
            $html_code .= '<td><img src="' . ECTBE_URL . 'assets/images/event-template-bg.png' . '" width="60" height="60"></td>';
        }
        else
        {
            $html_code .= '<td><img src="' . $event['eventimgurl'] . '" width="60" height="60"></td>';
        }

        $html_code .= '<td class="ectbe-table-tittle-name">' . __(esc_html($event['title']) , 'ectbe') . '</td>';
        if ($display_desc == 'yes')
        {
            $html_code .= ' <td>' . __($event['description'], 'ectbe') . '</td>';
        }

        $html_code .= '<td>' . __($ev_date , 'ectbe') . '</td>';
        if ($display_cate == 'yes')
        {
            $html_code .= '<td>' . __(esc_html($category) , 'ectbe') . '</td>';
        }
        $html_code .= '<td>' . __(esc_html($tagValues) , 'ectbe') . '</td>';

        if ($ectbe_venue == 'no')
        {
            $html_code .= '<td ><a href="' . esc_attr($venue_link) . '" >' . __(esc_html($venue) , 'ectbe') . '</a></td>';
        }
        $html_code .= '<td>' . __(esc_html($organizer) , 'ectbe') . '</td>
        <td>' . __(esc_html($event['eventcost'] == null ? 'NA' : $event['eventcost']) , 'ectbe') . '</td>
        <td ><a href="' . esc_attr($event['url']) . '" >' . __(esc_html("View More") , 'ectbe') . '</a></td></tr>';
        
    }

}

