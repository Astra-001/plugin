class DataTable extends elementorModules.frontend.handlers.Base {
    getDefaultSettings() {
        return {
            selectors: {
                firstSelector: '#ectbe-table-List',
            },
        };
    }
    getDefaultElements() {
        const selectors = this.getSettings('selectors');
        return {
            $firstSelector: this.$element.find(selectors.firstSelector),
        };
    }
    bindEvents() {
        var tableSelector = this.elements.$firstSelector;
        
        jQuery(document).ready(function() {
           tableSelector.DataTable({
            "searching": true,
            'dom' : 'rftli',
            aLengthMenu: [
                [25, 50, 100, 200, -1],
                [25, 50, 100, 200, "All"]
            ],
            'paging': true,
            "fnInfoCallback": function (oSettings, iStart, iEnd, iMax, iTotal, sPre) {
                return  iTotal + ' Posts (' + iMax+' in total)';
            }
           });
           var table = jQuery('#ectbe-table-List').DataTable();
           
           jQuery(" .dataTables_filter").prepend(jQuery(".ectbe-category-filter"));
           jQuery(".dataTables_length").append(jQuery("#ectbe-table-List_info"));
           
        

           var categoryIndex = 0;
           var tagIndex = 0;

           jQuery("#ectbe-table-List th").each(function (i) {
            
             if (jQuery(jQuery(this)).html() == "Category" ) {
        
               categoryIndex = i;
              
             }
             if (jQuery(jQuery(this)).html() == "Tags") {
                tagIndex = i;
              }
              
              
           });
           if(!categoryIndex){
            jQuery("#ectbe-categoryFilter").hide();
           }
        
           jQuery.fn.dataTable.ext.search.push(
            function (settings, data, dataIndex) {
              var selectedItemcat = jQuery('#ectbe-categoryFilter').val();
              var category = data[categoryIndex];

              if (selectedItemcat === "" || category.includes(selectedItemcat) ) {
                return true;
              }
              return false;
            });

            if(jQuery(".ectbe-table-infoDIv").text().length > 0 ){

            }

            jQuery.fn.dataTable.ext.search.push(
                function (settings, data, dataIndex) {
                  var selectedItem_Tag = jQuery('#ectbe-tagFilter').val().toLowerCase();
                  var tag = data[tagIndex];
                  if (selectedItem_Tag === "" || tag.includes(selectedItem_Tag) ) {
                    return true;
                  }
                  return false;
            });

            jQuery("#ectbe-categoryFilter").change(function (e) {
               
                table.draw();
            });
            jQuery("#ectbe-tagFilter").change(function (e) {
               
                table.draw();
            });
            jQuery(".ectbe-table-refresh").on('click',function(){
                let one = jQuery('#ectbe-categoryFilter, #ectbe-tagFilter').val('');
                table.draw();
            });
            table.draw();
            
        });
            

    }
}
jQuery(window).on('elementor/frontend/init', () => {

    const addHandler = ($element) => {
        elementorFrontend.elementsHandler.addHandler(DataTable, {
            $element,
        });
    };
    elementorFrontend.hooks.addAction('frontend/element_ready/the-events-calendar-addon.default', addHandler);
});